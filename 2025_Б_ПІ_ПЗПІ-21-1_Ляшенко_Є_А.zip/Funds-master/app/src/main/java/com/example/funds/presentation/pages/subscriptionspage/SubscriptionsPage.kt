package com.example.funds.presentation.pages.subscriptionspage

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.funds.presentation.pages.initiativelist.InitiativeCard
import com.example.funds.presentation.pages.initiativelist.SearchBar
import com.example.funds.presentation.pages.mainscreen.FundraisingSignalRClient
import com.example.funds.presentation.pages.raiseslist.Raise
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.sql.Types

data class Subscription(
    val id: Int,
    val initiativeId: Int,
    val initiative: Initiative,
    val subscribedAt: String
)

data class Initiative(
    val title: String,
    val description: String,
    val imageBase64: String
)

data class UserSettings(
    val notifyNewFundraising: Boolean,
    val notifyNewInitiative: Boolean,
    val notifyGoalReached: Boolean,
    val frequencyInHours: Int
)

@Composable
fun SubscriptionsPage(userToken: String) {
    val subscriptions = remember { mutableStateListOf<Subscription>() }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var showDialog by remember { mutableStateOf(false) }
    var userSettings by remember { mutableStateOf<UserSettings?>(null) }

    var searchQuery by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(Unit) {
        try {
            val response = fetchSubscriptions(userToken)
            subscriptions.clear()
            subscriptions.addAll(response)

            // Fetch user settings
            userSettings = fetchUserSettings(userToken)
        } catch (e: Exception) {
            Log.e("SubscriptionsPage", "Error", e)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            SearchBar(
                textFieldState = rememberTextFieldState().apply {
                    edit { replace(0, length, searchQuery) }
                },
                onSearch = { searchQuery = it },
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(onClick = { showDialog = true }) {
                Icon(Icons.Default.Settings, contentDescription = "Settings")
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(
                subscriptions.filter {
                    it.initiative.title.contains(searchQuery, ignoreCase = true) ||
                            it.initiative.description.contains(searchQuery, ignoreCase = true)
                },
                key = { it.id }
            ) { sub ->
                SubscribedInitiativeCard(
                    subscription = sub,
                    onUnsubscribeClick = { subscriptionId ->
                        val subscription = subscriptions.find { it.id == subscriptionId }
                        if (subscription != null) {
                            coroutineScope.launch {
                                val success = unsubscribeFromInitiative(subscription.id, userToken)
                                if (success) {
                                    subscriptions.remove(subscription)
                                    Toast.makeText(context, "Unsubscribed", Toast.LENGTH_SHORT).show()
                                }
                            }
                            FundraisingSignalRClient.unsubscribeFromInitiativeSignalR(subscription.initiativeId)
                        }
                    }
                )
            }
        }

        NotificationSettingsDialog(
            visible = showDialog,
            settings = userSettings ?: UserSettings(true, true, true, 1),
            onDismiss = { showDialog = false },
            onSave = { newSettings ->
                coroutineScope.launch {
                    updateUserSettings(userToken, newSettings)
                    userSettings = newSettings
                    Toast.makeText(context, "Settings saved", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }
}

@Composable
fun SubscribedInitiativeCard(
    subscription: Subscription,
    onUnsubscribeClick: (Int) -> Unit
) {
    val imageBitmap by produceState<ImageBitmap?>(initialValue = null, subscription.initiative.imageBase64) {
        value = withContext(Dispatchers.IO) {
            decodeBase64ToBitmap(subscription.initiative.imageBase64)?.asImageBitmap()
        }
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(8.dp),
        modifier = Modifier.fillMaxWidth().height(200.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (imageBitmap != null) {
                    Image(
                        bitmap = imageBitmap!!,
                        contentDescription = null,
                        modifier = Modifier
                            .size(90.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.LightGray),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = subscription.initiative.title,
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                IconButton(onClick = { onUnsubscribeClick(subscription.id) }) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Unsubscribe"
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = subscription.initiative.description,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray)
            )
        }
    }
}

@Composable
fun NotificationSettingsDialog(
    visible: Boolean,
    settings: UserSettings,
    onDismiss: () -> Unit,
    onSave: (UserSettings) -> Unit
) {
    if (!visible) return

    var fundraising by remember { mutableStateOf(settings.notifyNewFundraising) }
    var initiative by remember { mutableStateOf(settings.notifyNewInitiative) }
    var closed by remember { mutableStateOf(settings.notifyGoalReached) }
    var hours by remember { mutableStateOf(settings.frequencyInHours.coerceIn(1, 24)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Notification Settings") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = fundraising,
                        onCheckedChange = { fundraising = it },
                        colors = CheckboxDefaults.colors(
                            checkedColor = Color.Black,
                            uncheckedColor = Color.Gray,
                            checkmarkColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("New raises")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = initiative,
                        onCheckedChange = { initiative = it },
                        colors = CheckboxDefaults.colors(
                            checkedColor = Color.Black,
                            uncheckedColor = Color.Gray,
                            checkmarkColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("New initiatives")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = closed,
                        onCheckedChange = { closed = it },
                        colors = CheckboxDefaults.colors(
                            checkedColor = Color.Black,
                            uncheckedColor = Color.Gray,
                            checkmarkColor = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Closed raises")
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text("Notify every: $hours hour(s)")
                Slider(
                    value = hours.toFloat(),
                    onValueChange = { hours = it.toInt().coerceIn(1, 24) },
                    valueRange = 1f..24f,
                    steps = 22,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.Black,
                        activeTrackColor = Color.Gray,
                        activeTickColor = Color.Black,
                        inactiveTickColor = Color.Gray,
                        inactiveTrackColor = Color.LightGray,
                        disabledThumbColor = Color.Gray
                    )
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        UserSettings(
                            notifyNewFundraising = fundraising,
                            notifyNewInitiative = initiative,
                            notifyGoalReached = closed,
                            frequencyInHours = hours
                        )
                    )
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
            ) {
                Text("Save", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
            ) {
                Text("Cancel", color = Color.White)
            }
        }
    )
}

fun decodeBase64ToBitmap(base64: String): Bitmap? {
    return try {
        val decodedBytes = Base64.decode(base64, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}

suspend fun fetchSubscriptions(token: String): List<Subscription> {
    return try {
        withContext(Dispatchers.IO) {
            val client = OkHttpClient()
            val request = Request.Builder()
                .url("http://10.0.2.2:5000/api/Subscribe/MySubscribe")
                .addHeader("accept", "application/json")
                .addHeader("Authorization", "Bearer $token")
                .build()

            Log.d("SubscriptionsResponse", "$request")

            val response = client.newCall(request).execute()

            if (!response.isSuccessful) {
                Log.e("SubscriptionsResponse", "HTTP Error: ${response.code}")
                return@withContext emptyList()
            }

            val body = response.body?.string() ?: return@withContext emptyList()
            Log.d("SubscriptionsResponse", body)

            val jsonArray = JSONArray(body)

            (0 until jsonArray.length()).map { i ->
                val obj = jsonArray.getJSONObject(i)
                val initiativeObj = obj.getJSONObject("initiative")

                Subscription(
                    id = obj.getInt("id"),
                    initiativeId = obj.getInt("initiativeId"),
                    initiative = Initiative(
                        title = initiativeObj.getString("title"),
                        description = initiativeObj.getString("description"),
                        imageBase64 = initiativeObj.optString("imageBase64", "")
                    ),
                    subscribedAt = obj.getString("subscribedAt")
                )
            }
        }
    } catch (e: Exception) {
        Log.e("SubscriptionsResponse", "Failed to fetch subscriptions", e)
        emptyList()
    }
}

suspend fun unsubscribeFromInitiative(initiativeId: Int, token: String): Boolean {
    return try {
        withContext(Dispatchers.IO) {
            val client = OkHttpClient()
            val request = Request.Builder()
                .url("http://10.0.2.2:5000/api/Subscribe/UnsubscribeFromInitiative?id=$initiativeId")
                .delete()
                .addHeader("accept", "*/*")
                .addHeader("Authorization", "Bearer $token")
                .build()
            Log.d("SubscriptionsRequest", "$request")
            val response = client.newCall(request).execute()

            Log.d("UnsubscribeResponse", "HTTP ${response.code}")
            Log.d("UnsubscribeResponse", "HTTP ${response.message}")

            response.isSuccessful
        }
    } catch (e: Exception) {
        Log.e("UnsubscribeResponse", "Failed to unsubscribe", e)
        false
    }
}

suspend fun fetchUserSettings(token: String): UserSettings? = withContext(Dispatchers.IO) {
    val client = OkHttpClient()
    val request = Request.Builder()
        .url("http://10.0.2.2:5000/api/User/GetUserSettings")
        .addHeader("Authorization", "Bearer $token")
        .build()

    val response = client.newCall(request).execute()
    val body = response.body?.string() ?: return@withContext null
    val json = JSONObject(body)
    return@withContext UserSettings(
        notifyNewFundraising = json.getBoolean("notifyNewFundraising"),
        notifyNewInitiative = json.getBoolean("notifyNewInitiative"),
        notifyGoalReached = json.getBoolean("notifyGoalReached"),
        frequencyInHours = json.getInt("frequencyInHours")
    )
}

suspend fun updateUserSettings(token: String, settings: UserSettings) = withContext(Dispatchers.IO) {
    val client = OkHttpClient()
    val json = JSONObject().apply {
        put("notifyNewFundraising", settings.notifyNewFundraising)
        put("notifyNewInitiative", settings.notifyNewInitiative)
        put("notifyGoalReached", settings.notifyGoalReached)
        put("frequencyInHours", settings.frequencyInHours)
    }
    val request = Request.Builder()
        .url("http://10.0.2.2:5000/api/User/UpdateUserSettings")
        .put(json.toString().toRequestBody("application/json-patch+json".toMediaType()))
        .addHeader("Authorization", "Bearer $token")
        .build()
    client.newCall(request).execute().close()
}