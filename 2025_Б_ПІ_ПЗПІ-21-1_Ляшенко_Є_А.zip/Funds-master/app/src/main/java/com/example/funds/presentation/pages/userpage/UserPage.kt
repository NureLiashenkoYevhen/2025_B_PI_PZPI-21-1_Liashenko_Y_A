package com.example.funds.presentation.pages.userpage

import JWT_TOKEN_KEY
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.funds.R
import com.example.funds.presentation.pages.mainscreen.Category
import com.example.funds.presentation.pages.mainscreen.fetchUserInfo
import dataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.FormBody
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.InputStream
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

data class UserData(
    val firstName: String,
    val secondName: String,
    val email: String,
    val imageBase64: String
)

data class DonationEntry(
    val time: String,
    val amount: String,
    val initiativeName: String,
    val color: Color,
    val extraInfo: DonationExtra? = null
)

data class DonationExtra(
    val title: String,
    val deadline: String,
    val goal: String
)

@Serializable
data class DonationDto(
    val id: Int,
    val amount: Double,
    val date: String,
    val fundraisingTitle: String,
    val fundraisingDeadline: String,
    val fundraisingGoal: Double,
    val initiativeCategoryId: Int,
    val initiativeTitle: String
)
@Composable
fun UserPage(user: UserData, onSignOut: () -> Unit, categories: List<Category>, updateUserData: ()-> Unit) {
    val context = LocalContext.current
    var token by remember { mutableStateOf<String?>(null) }
    var donationGroups by remember { mutableStateOf<Map<String, List<DonationEntry>>>(emptyMap()) }
    var emailVerified by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        token = getJwtTokenFromDataStore(context)
        if (token == null) {
            Log.e("UserPage", "JWT token not found")
            return@LaunchedEffect
        }

        donationGroups = fetchUserDonations(token!!, categories)

        token?.let {
            val verified = checkUserVerificationStatus(it)
            emailVerified = verified
        }
    }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        ProfileHeader(user = user, onSignOut = onSignOut,
            updateUserData = updateUserData,
            emailVerified = emailVerified,
            onEmailVerified = { emailVerified = true })

        Spacer(modifier = Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = ImageVector.vectorResource(id = R.drawable.donation_history),
                contentDescription = null,
                modifier = Modifier
                    .padding(start = 4.dp)
                    .size(18.dp),
                tint = Color.Black
            )
            Text("Your donations:", style = MaterialTheme.typography.titleMedium)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            modifier = Modifier
                .fillMaxSize(),
            elevation = CardDefaults.cardElevation(6.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(12.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                if (donationGroups.isEmpty()) {
                    Text("No donations found.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    donationGroups.forEach { (date, donations) ->
                        DateDonationGroup(date, donations)
                    }
                }

            }
        }
    }
}

@Composable
fun ProfileHeader(user: UserData, onSignOut: () -> Unit, updateUserData: ()-> Unit, emailVerified: Boolean,onEmailVerified: () -> Unit) {
    var name by remember { mutableStateOf("${user.firstName} ${user.secondName}") }
    var email by remember { mutableStateOf(user.email) }
    var isEditingName by remember { mutableStateOf(false) }
    var isEditingEmail by remember { mutableStateOf(false) }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var token by remember { mutableStateOf<String?>(null) }

    val imageBitmap = remember(user.imageBase64) {
        base64ToImageBitmap(user.imageBase64)
    }
    var showVerificationDialog by remember { mutableStateOf(false) }
    var verificationCode by remember { mutableStateOf("") }
    var isVerifying by remember { mutableStateOf(false) }

    LaunchedEffect(token) {
        token = getJwtTokenFromDataStore(context)
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            selectedImageUri = it
            scope.launch {
                if (token != null) {
                    val parts = name.trim().split(" ")
                    val firstName = parts.getOrNull(0) ?: ""
                    val secondName = parts.getOrNull(1) ?: ""

                    val success = editUserProfile(
                        firstName = firstName,
                        secondName = secondName,
                        imageUri = it,
                        context = context
                    )

                    if (success) {
                        Toast.makeText(context, "Image uploaded", Toast.LENGTH_SHORT).show()
                        updateUserData()
                    } else {
                        Toast.makeText(context, "Image upload failed", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(context, "JWT token not available", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(contentAlignment = Alignment.BottomEnd) {
                if (selectedImageUri != null) {
                    AsyncImage(
                        model = selectedImageUri,
                        contentDescription = null,
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                    )
                } else if (imageBitmap != null) {
                    Image(
                        bitmap = imageBitmap,
                        contentDescription = null,
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        modifier = Modifier
                            .size(90.dp)
                            .background(Color.LightGray, CircleShape)
                            .padding(8.dp)
                    )
                }

                IconButton(
                    onClick = { launcher.launch("image/*") },
                    modifier = Modifier
                        .size(20.dp)
                        .background(Color.Blue, CircleShape)
                        .padding(2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit image",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                // Name row
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.weight(1f)) {
                        if (isEditingName) {
                            OutlinedTextField(
                                value = name,
                                onValueChange = { name = it },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = MaterialTheme.typography.titleMedium
                            )
                        } else {
                            Text(
                                text = name,
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.align(Alignment.CenterStart)
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            if (isEditingName && token != null) {
                                val parts = name.trim().split(" ")
                                val newFirstName = parts.getOrNull(0) ?: ""
                                val newSecondName = parts.getOrNull(1) ?: ""

                                val nameChanged = newFirstName != user.firstName || newSecondName != user.secondName
                                val imageChanged = selectedImageUri != null

                                if (nameChanged || imageChanged) {
                                    scope.launch {
                                        val success = editUserProfile(
                                            firstName = newFirstName,
                                            secondName = newSecondName,
                                            imageUri = selectedImageUri,
                                            context = context
                                        )
                                        if (success) {
                                            Toast.makeText(context, "Name updated", Toast.LENGTH_SHORT).show()
                                            updateUserData()
                                        } else {
                                            Toast.makeText(context, "Failed to update", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                } else {
                                    Toast.makeText(context, "No changes to update", Toast.LENGTH_SHORT).show()
                                }
                            }
                            isEditingName = !isEditingName
                        },
                        modifier = Modifier
                            .size(18.dp)
                            .background(Color.Blue, CircleShape)
                            .padding(2.dp)
                    ) {
                        Icon(
                            imageVector = if (isEditingName) Icons.Default.Check else Icons.Default.Edit,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }

                // Email row
                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.weight(1f)) {
                        if (isEditingEmail) {
                            OutlinedTextField(
                                value = email,
                                onValueChange = { email = it },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = MaterialTheme.typography.bodySmall
                            )
                        } else {
                            Text(
                                text = email,
                                color = Color.Gray,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.align(Alignment.CenterStart)
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            if (isEditingEmail && token != null) {
                                val parts = name.trim().split(" ")
                                val firstName = parts.getOrNull(0) ?: ""
                                val secondName = parts.getOrNull(1) ?: ""

                                val emailChanged = email != user.email
                                if (emailChanged) {
                                    scope.launch {
                                        val success = editUserProfile(
                                            firstName = firstName,
                                            secondName = secondName,
                                            imageUri = selectedImageUri,
                                            email = email,
                                            context = context
                                        )
                                        if (success) {
                                            Toast.makeText(context, "Email updated, please authorise", Toast.LENGTH_SHORT).show()
                                            onSignOut()
                                        } else {
                                            Toast.makeText(context, "Failed to update email", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                } else {
                                    Toast.makeText(context, "No changes to update", Toast.LENGTH_SHORT).show()
                                }
                            }
                            isEditingEmail = !isEditingEmail
                        },
                        modifier = Modifier
                            .size(16.dp)
                            .background(Color.Blue, CircleShape)
                            .padding(2.dp)
                    ) {
                        Icon(
                            imageVector = if (isEditingEmail) Icons.Default.Check else Icons.Default.Edit,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(10.dp)
                        )
                    }
                }

                // Second row: buttons
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (!emailVerified) {
                        Button(
                            onClick = {
                                showVerificationDialog = true
                                scope.launch {
                                    val success = sendVerificationCode(token!!)
                                    if(!success){
                                        Toast.makeText(context, "Verification code sent", Toast.LENGTH_SHORT).show();
                                    }else{
                                        Toast.makeText(context, "Failed to send code", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                            modifier = Modifier
                                .weight(1.2f)
                                .height(35.dp)
                        ) {
                            Text("Verify Email", color = Color.White)
                        }
                    } else {
                        TextButton(onClick = {}, modifier = Modifier){
                            Text("Email Verified",
                                color = Color(0xFF3C763D),
                                modifier = Modifier.height(35.dp))
                        }
                    }

                    Spacer(modifier = Modifier.width(5.dp))

                    Button(
                        onClick = onSignOut,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                        modifier = Modifier
                            .weight(1f)
                            .height(35.dp)
                    ) {
                        Text("Sign Out", color = Color.White)
                    }
                }

                if (showVerificationDialog) {
                    AlertDialog(
                        onDismissRequest = { showVerificationDialog = false },
                        title = { Text("Enter Verification Code") },
                        text = {
                            Column {
                                OutlinedTextField(
                                    value = verificationCode,
                                    onValueChange = { if (it.length <= 6) verificationCode = it },
                                    label = { Text("6-digit code") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true
                                )
                            }
                        },
                        confirmButton = {
                            TextButton(
                                onClick = {
                                    scope.launch {
                                        isVerifying = true
                                        val success = verifyEmailCode(verificationCode, token ?: "")
                                        isVerifying = false
                                        if (success) {
                                            Toast.makeText(context, "Email verified", Toast.LENGTH_SHORT).show()
                                            showVerificationDialog = false
                                            onEmailVerified()
                                        } else {
                                            Toast.makeText(context, "Invalid or expired code", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                enabled = verificationCode.length == 6 && !isVerifying
                            ) {
                                Text("Confirm")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showVerificationDialog = false }) {
                                Text("Cancel")
                            }
                        }
                    )
                }
            }
        }
    }
}


@Composable
fun DateDonationGroup(date: String, donations: List<DonationEntry>) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.Center
    ) {
        Text(
            text = "[$date]",
            style = MaterialTheme.typography.titleMedium,
            color = Color.Black
        )
    }

    donations.forEach { donation ->
        var expanded by remember { mutableStateOf(false) }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded }
        ) {
            HorizontalDivider(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                thickness = 1.dp,
                color = Color.LightGray
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = donation.time)
                    Text(
                        text = donation.amount,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    )
                }

                Row(
                    verticalAlignment = Alignment.Top,
                    modifier = Modifier
                        .widthIn(max = 250.dp)
                        .fillMaxHeight()
                ) {
                    Text(
                        text = donation.initiativeName,
                        color = donation.color,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        modifier = Modifier
                            .padding(start = 4.dp)
                            .align(Alignment.CenterVertically)
                    )
                }
            }

            if (expanded && donation.extraInfo != null) {

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = donation.extraInfo.title,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Deadline: ${donation.extraInfo.deadline}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Normal,
                                color = Color.Black
                            ))
                        Text("Goal: ${donation.extraInfo.goal}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            ))
                    }
                }

                HorizontalDivider(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    thickness = 1.dp,
                    color = Color.LightGray
                )
            }
        }
    }
}

suspend fun fetchUserDonations(token: String, categories: List<Category>): Map<String, List<DonationEntry>> {
    val client = OkHttpClient()
    val request = Request.Builder()
        .url("http://10.0.2.2:5000/api/Donate/MyDonates")
        .addHeader("Authorization", "Bearer $token")
        .addHeader("accept", "text/plain")
        .build()

    return withContext(Dispatchers.IO) {
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) return@withContext emptyMap()

        val body = response.body?.string()?.takeIf { it.isNotBlank() } ?: return@withContext emptyMap()
        val json = Json { ignoreUnknownKeys = true }
        val donations = json.decodeFromString<List<DonationDto>>(body)

        donations.groupBy {
            runCatching {
                LocalDateTime.parse(it.date)
                    .toLocalDate()
                    .format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
            }.getOrElse { "Invalid date" }
        }.mapValues { (_, group) ->
            group.map {
                val parsedTime = runCatching {
                    LocalDateTime.parse(it.date).toLocalTime()
                        .format(DateTimeFormatter.ofPattern("HH:mm"))
                }.getOrElse { "??:??" }

                val parsedDeadline = runCatching {
                    LocalDateTime.parse(it.fundraisingDeadline).toLocalDate()
                        .format(DateTimeFormatter.ofPattern("dd.MM.yyyy"))
                }.getOrElse { "Invalid deadline" }

                val color = categories.firstOrNull { category ->
                    category.id == it.initiativeCategoryId
                }?.color ?: Color.Gray

                DonationEntry(
                    time = parsedTime,
                    amount = "$%,d".format(it.amount.toInt()),
                    initiativeName = it.initiativeTitle,
                    color = color,
                    extraInfo = DonationExtra(
                        title = it.fundraisingTitle,
                        deadline = parsedDeadline,
                        goal = "$%,d".format(it.fundraisingGoal.toInt())
                    )
                )
            }
        }
    }
}

fun base64ToImageBitmap(base64String: String): ImageBitmap? {
    return try {
        val cleanBase64 = base64String
            .substringAfter("base64,", base64String) // Skip any headers if present
        val decodedBytes = Base64.decode(cleanBase64, Base64.DEFAULT)
        val bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
        bitmap?.asImageBitmap()
    } catch (e: Exception) {
        //e.printStackTrace()
        null
    }
}

suspend fun editUserProfile(
    firstName: String? = null,
    secondName: String? = null,
    email: String? = null,
    imageUri: Uri? = null,
    context: Context
): Boolean {
    return try {
        val token = getJwtTokenFromDataStore(context)
        if (token == null) {
            Log.e("EditProfile", "JWT token missing")
            return false
        }

        val client = OkHttpClient()
        val builder = MultipartBody.Builder().setType(MultipartBody.FORM)

        var imageBytes: ByteArray? = null
        var mediaType: MediaType? = null
        var fileName: String? = null

        builder.addFormDataPart("FirstName", firstName ?: "")
        builder.addFormDataPart("SecondName", secondName ?: "")
        builder.addFormDataPart("Email", email ?: "")

        if (imageUri != null) {
            val inputStream = context.contentResolver.openInputStream(imageUri)
            imageBytes = inputStream?.readBytes()
            fileName = "avatar_image"
            mediaType = context.contentResolver.getType(imageUri)?.toMediaTypeOrNull()
                ?: "image/*".toMediaType()

            if (imageBytes != null) {
                builder.addFormDataPart("AvatarFile", fileName, imageBytes.toRequestBody(mediaType))
                Log.d("EditProfile", "Added image to request: $fileName (${imageBytes.size} bytes, $mediaType)")
            } else {
                builder.addFormDataPart("AvatarFile", "", "".toRequestBody("text/plain".toMediaType()))
                Log.w("EditProfile", "Image URI provided but no bytes read")
            }
        } else {
            builder.addFormDataPart("AvatarFile", "", "".toRequestBody("text/plain".toMediaType()))
            Log.d("EditProfile", "Added empty AvatarFile field to request")
        }

        builder.addFormDataPart("PhoneNumber", "")

        //Log.d("EditProfile", "Form data - FirstName: $firstName, SecondName: $secondName")

        val requestBody = builder.build()

        requestBody.parts.forEachIndexed { index, part ->
            val headers = part.headers
            val bodySize = try {
                part.body.contentLength()
            } catch (e: Exception) {
                -1
            }
            //Log.d("EditProfile", "Part[$index]: headers=$headers, size=$bodySize")
        }

        val request = Request.Builder()
            .url("http://10.0.2.2:5000/api/User/EditUserProfile")
            .addHeader("accept", "text/plain")
            .addHeader("Authorization", "Bearer $token")
            .put(requestBody)
            .build()

        Log.d("EditProfile", "Sending request to ${request.url}")
        Log.d("EditProfile", "Headers: ${request.headers}")

        val response = withContext(Dispatchers.IO) {
            client.newCall(request).execute()
        }

        val responseBody = response.body?.string()
        Log.d("EditProfile", "Response Code: ${response.code}")
        Log.d("EditProfile", "Response Body: $responseBody")

        if (!response.isSuccessful) {
            Log.e("EditProfile", "Server returned error: ${response.code}")
        }
        response.isSuccessful
    } catch (e: Exception) {
        Log.e("EditProfile", "Exception occurred during profile update", e)
        false
    }
}

suspend fun checkUserVerificationStatus(token: String): Boolean {
    return try {
        val client = OkHttpClient()

        val request = Request.Builder()
            .url("http://10.0.2.2:5000/api/TwoFactor/has-2fa")
            .addHeader("accept", "*/*")
            .addHeader("Authorization", "Bearer $token")
            .build()
        Log.d("Verification", "$request")

        val response = withContext(Dispatchers.IO) {
            client.newCall(request).execute()
        }

        val responseBody = response.body?.string()?.trim()

        response.isSuccessful && responseBody == "true"
    } catch (e: Exception) {
        Log.e("VerifyEmail", "Verification failed", e)
        false
    }
}

suspend fun sendVerificationCode(token: String): Boolean {
    if (token.isEmpty()) return false

    return try {
        val client = OkHttpClient()

        val emptyBody = "".toRequestBody("application/json".toMediaTypeOrNull())

        val request = Request.Builder()
            .url("http://10.0.2.2:5000/api/TwoFactor/send-2fa-code")
            .post(emptyBody)
            .addHeader("accept", "*/*")
            .addHeader("Authorization", "Bearer $token")
            .build()

        Log.d("Verification code sent:", "$request")

        val response = withContext(Dispatchers.IO) {
            client.newCall(request).execute()
        }

        val responseBody = response.body?.string()?.trim()
        Log.d("Response from /send-2fa-code:", "$responseBody")

        response.isSuccessful && responseBody == "true"
    } catch (e: Exception) {
        Log.e("CodeSend", "Code send failed", e)
        false
    }
}

suspend fun verifyEmailCode(code: String, token: String): Boolean {
    return try {
        val client = OkHttpClient()

        val mediaType = "application/json-patch+json".toMediaType()
        val jsonBody = """{ "code": "$code" }"""
        val requestBody = jsonBody.toRequestBody(mediaType)

        val request = Request.Builder()
            .url("http://10.0.2.2:5000/api/TwoFactor/verify-2fa")
            .post(requestBody)
            .addHeader("Authorization", "Bearer $token")
            .addHeader("accept", "*/*")
            .build()

        val response = withContext(Dispatchers.IO) {
            client.newCall(request).execute()
        }

        Log.d("VerifyEmail", "Response code: ${response.code}, body: ${response.body?.string()}")
        response.isSuccessful
    } catch (e: Exception) {
        Log.e("VerifyEmail", "Verification failed", e)
        false
    }
}

suspend fun getJwtTokenFromDataStore(context: Context): String? {
    val dataStore = context.dataStore
    return dataStore.data
        .map { it[JWT_TOKEN_KEY] }
        .firstOrNull()
}