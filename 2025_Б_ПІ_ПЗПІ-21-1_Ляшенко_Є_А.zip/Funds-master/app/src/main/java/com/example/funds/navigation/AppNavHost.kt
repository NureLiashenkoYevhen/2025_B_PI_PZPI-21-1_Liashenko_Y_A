package com.example.funds.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.funds.presentation.pages.initiativelist.InitiativeList
import com.example.funds.presentation.pages.mainscreen.Category
import com.example.funds.presentation.pages.mainscreen.Initiative
import com.example.funds.presentation.pages.mainscreen.fetchRaiseById
import com.example.funds.presentation.pages.raisedetails.RaiseDetails
import com.example.funds.presentation.pages.raiseslist.Raise
import com.example.funds.presentation.pages.raiseslist.RaisesList
import com.example.funds.presentation.pages.subscriptionspage.SubscriptionsPage
import com.example.funds.presentation.pages.userpage.AuthScreen
import com.example.funds.presentation.pages.userpage.UserData
import com.example.funds.presentation.pages.userpage.UserPage

@Composable
fun AppNavHost(
    navController: NavHostController,
    jwtToken: String?,
    userData: UserData?,
    categories: List<Category>,
    initiatives: List<Initiative>,
    updateUserData: () -> Unit,
    onLoginSuccess: (String) -> Unit,
    onLogout: () -> Unit
) {
    NavHost(navController, startDestination = "home") {
        composable("profile") {
            if (jwtToken != null && userData != null) {
                UserPage(
                    user = userData,
                    onSignOut = onLogout,
                    categories = categories,
                    updateUserData = updateUserData
                )
            } else {
                AuthScreen(onLoginSuccess = onLoginSuccess)
            }
        }

        composable("subscriptions") {
            if (jwtToken != null && userData != null) {
                SubscriptionsPage(userToken = jwtToken)
            } else {
                AuthScreen(onLoginSuccess = onLoginSuccess)
            }
        }

        composable(
            "initiative/{initiativeId}",
            arguments = listOf(navArgument("initiativeId") { type = NavType.IntType })
        ) { backStackEntry ->
            val initiativeId = backStackEntry.arguments?.getInt("initiativeId") ?: return@composable
            val initiative = initiatives.find { it.id == initiativeId }

            if (initiative != null) {
                RaisesList(
                    initiativeId = initiative.id,
                    initiativeTitle = initiative.title,
                    initiativeColor = initiative.category.color,
                    onBack = { navController.popBackStack() },
                    onRaiseClick = { raise ->
                        navController.navigate("raise/${raise.id}")
                    }
                )
            }
        }

        composable(
            "raise/{raiseId}",
            arguments = listOf(navArgument("raiseId") { type = NavType.IntType })
        ) { backStackEntry ->
            val raiseId = backStackEntry.arguments?.getInt("raiseId") ?: return@composable

            val raiseState = produceState<Raise?>(initialValue = null, raiseId) {
                value = fetchRaiseById(raiseId)
            }

            val raise = raiseState.value
            val initiative = raise?.let { r -> initiatives.find { it.id == r.initiativeId } }

            if (raise != null && initiative != null) {
                RaiseDetails(
                    initiativeIcon = initiative.imageBase64,
                    raise = raise,
                    isUserLoggedIn = jwtToken != null,
                    onBack = { navController.popBackStack() },
                    onNavigateToAuth = {
                        navController.navigate("profile") {
                            popUpTo("home")
                        }
                    }
                )
            }
        }
    }
}
