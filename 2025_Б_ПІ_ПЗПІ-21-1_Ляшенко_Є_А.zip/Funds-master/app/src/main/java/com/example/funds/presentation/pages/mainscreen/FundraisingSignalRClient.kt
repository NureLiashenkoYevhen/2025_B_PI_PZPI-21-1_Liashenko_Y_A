package com.example.funds.presentation.pages.mainscreen

import android.util.Log
import com.microsoft.signalr.HubConnection
import com.microsoft.signalr.HubConnectionBuilder
import com.microsoft.signalr.HubConnectionState

object FundraisingSignalRClient {
    private var hubConnection: HubConnection? = null

    data class FundraisingDto(
        val fundraisingId: Int,
        val title: String,
        val goal: Double,
        val deadline: String
    )

    fun connect(jwtToken: String?, onNewFundraising: (FundraisingDto) -> Unit) {
        if (hubConnection == null || hubConnection?.connectionState != HubConnectionState.CONNECTED) {
            hubConnection = HubConnectionBuilder
                .create("http://10.0.2.2:5000/hubs/fundraising")
                .withHeader("Authorization", "Bearer $jwtToken")
                .build()

            hubConnection?.start()?.subscribe({
                Log.d("SignalR", "Connected to SignalR")
            }, { error ->
                Log.e("SignalR", "Error starting SignalR connection: ${error.message}", error)
            })

            hubConnection?.on("NewFundraisingCreated", {
                    update: FundraisingDto ->
                Log.d("SignalR", "Triggered object: $update")
                onNewFundraising(
                    FundraisingDto(
                        fundraisingId = update.fundraisingId,
                        title = update.title,
                        goal = update.goal,
                        deadline = update.deadline
                    )
                )
            }, FundraisingDto::class.java)

            hubConnection?.on("UnknownEvent", { args: List<Any> ->
                Log.w("SignalR", "Unknown event triggered with args: $args")
            }, List::class.java)

            hubConnection?.onClosed { error ->
                Log.e("SignalR", "Connection closed: ${error?.message}", error)
            }
        }
    }

    fun subscribeToInitiativeSignalR(initiativeId: Int) {
        if (hubConnection?.connectionState == HubConnectionState.CONNECTED) {
            hubConnection?.invoke("SubscribeToInitiative", initiativeId);
            Log.d("SignalR", "Subscribed to initiative $initiativeId")
        } else {
            Log.w("SignalR", "Hub is not connected. Cannot subscribe to initiative.")
        }
    }

    fun unsubscribeFromInitiativeSignalR(initiativeId: Int) {
        if (hubConnection?.connectionState == HubConnectionState.CONNECTED) {
            hubConnection?.invoke("UnsubscribeFromInitiative", initiativeId);
            Log.d("SignalR", "Unsubscribed from initiative $initiativeId")
        } else {
            Log.w("SignalR", "Hub is not connected. Cannot unsubscribe from initiative.")
        }
    }
    
    fun disconnect() {
        hubConnection?.stop()
    }
}