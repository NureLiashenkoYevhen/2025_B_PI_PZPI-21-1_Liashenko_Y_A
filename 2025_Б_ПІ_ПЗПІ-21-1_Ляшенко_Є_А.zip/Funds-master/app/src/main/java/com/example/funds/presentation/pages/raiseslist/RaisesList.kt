package com.example.funds.presentation.pages.raiseslist

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.funds.presentation.pages.initiativelist.SearchBar
import com.example.funds.presentation.pages.mainscreen.FundraisingSignalRClient
import com.example.funds.presentation.pages.userpage.getJwtTokenFromDataStore
import com.patrykandpatrick.vico.compose.cartesian.CartesianChartHost
import com.patrykandpatrick.vico.compose.cartesian.axis.rememberBottom
import com.patrykandpatrick.vico.compose.cartesian.axis.rememberStart
import com.patrykandpatrick.vico.compose.cartesian.layer.rememberColumnCartesianLayer
import com.patrykandpatrick.vico.compose.cartesian.layer.rememberLineCartesianLayer
import com.patrykandpatrick.vico.compose.cartesian.rememberCartesianChart
import com.patrykandpatrick.vico.compose.common.component.rememberLineComponent
import com.patrykandpatrick.vico.compose.common.component.rememberTextComponent
import com.patrykandpatrick.vico.compose.common.fill
import com.patrykandpatrick.vico.compose.common.vicoTheme
import com.patrykandpatrick.vico.core.cartesian.axis.Axis
import com.patrykandpatrick.vico.core.cartesian.axis.HorizontalAxis
import com.patrykandpatrick.vico.core.cartesian.axis.VerticalAxis
import com.patrykandpatrick.vico.core.cartesian.data.CartesianChartModelProducer
import com.patrykandpatrick.vico.core.cartesian.data.CartesianLayerRangeProvider
import com.patrykandpatrick.vico.core.cartesian.data.columnSeries
import com.patrykandpatrick.vico.core.cartesian.data.lineSeries
import com.patrykandpatrick.vico.core.cartesian.layer.ColumnCartesianLayer
import com.patrykandpatrick.vico.core.cartesian.layer.LineCartesianLayer
import com.patrykandpatrick.vico.core.common.Defaults
import com.patrykandpatrick.vico.core.common.data.CartesianLayerDrawingModelInterpolator
import com.patrykandpatrick.vico.core.common.shape.CorneredShape
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter

data class Raise(
    val id: Int,
    val name: String,
    val goal: Int,
    val deadlineDate: String,
    val initiativeId: Int
)

data class InitiativeStat(
    val date: String,
    val totalAmount: Int
)

enum class RaiseSortType(val label: String) {
    GOAL("$ Goal"),
    DEADLINE("Deadline")
}

@Composable
fun RaisesList(
    initiativeId: Int,
    initiativeTitle: String,
    initiativeColor: Color,
    onBack: () -> Unit,
    onRaiseClick: (Raise) -> Unit
) {
    val context = LocalContext.current
    val textFieldState = rememberTextFieldState()
    var selectedSort: RaiseSortType by remember { mutableStateOf(RaiseSortType.DEADLINE) }
    var sortAscending by remember { mutableStateOf(true) }

    var raises by remember { mutableStateOf<List<Raise>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var token by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()
    var showChart by remember { mutableStateOf(false) }
    var stats by remember { mutableStateOf<List<InitiativeStat>>(emptyList()) }

    if (showChart) {
        StatChartDialog(
            stats = stats,
            onDismiss = { showChart = false }
        )
    }

    LaunchedEffect(initiativeId) {
        isLoading = true
        token = getJwtTokenFromDataStore(context)

        withContext(Dispatchers.IO) {
            raises = fetchRaisesForInitiative(initiativeId)
        }

        isLoading = false
    }

    val filteredRaises = remember(textFieldState.text, selectedSort, sortAscending, raises) {
        var list = raises.filter {
            it.name.contains(textFieldState.text, ignoreCase = true)
        }

        list = when (selectedSort) {
            RaiseSortType.GOAL -> if (sortAscending) list.sortedBy { it.goal } else list.sortedByDescending { it.goal }
            RaiseSortType.DEADLINE -> if (sortAscending) list.sortedBy { it.deadlineDate } else list.sortedByDescending { it.deadlineDate }
        }

        list
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
            }
            Text(
                text = initiativeTitle,
                style = MaterialTheme.typography.headlineSmall,
                color = initiativeColor,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = {
                scope.launch {
                    stats = fetchInitiativeStats(initiativeId)
                    /* mock data
                    stats = listOf(
                        InitiativeStat("2025-06-10T00:00:00", 400),
                        InitiativeStat("2025-06-11T00:00:00", 1200),
                        InitiativeStat("2025-06-12T00:00:00", 550),
                        InitiativeStat("2025-06-13T00:00:00", 890),
                        InitiativeStat("2025-06-14T00:00:00", 2000),
                        InitiativeStat("2025-06-15T00:00:00", 10090),
                        InitiativeStat("2025-06-16T00:00:00", 890),
                        InitiativeStat("2025-06-17T00:00:00", 2000),
                        InitiativeStat("2025-06-18T00:00:00", 10090)
                    )*/
                    showChart = true
                }
            }) {
                Icon(Icons.AutoMirrored.Default.List, contentDescription = "Show Chart")
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SearchBar(
                textFieldState = textFieldState,
                onSearch = {},
                modifier = Modifier.weight(1.5f)
            )
            RaiseSortDropDown(
                selectedSort = selectedSort,
                onSortSelected = { selectedSort = it },
                sortAscending = sortAscending,
                onToggleOrder = { sortAscending = !sortAscending },
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = {
                scope.launch {
                    val success = subscribeToInitiative(initiativeId, token)
                    if (success) {
                        FundraisingSignalRClient.subscribeToInitiativeSignalR(initiativeId);
                        Toast.makeText(context,"Subscribed to $initiativeTitle",Toast.LENGTH_SHORT).show();
                    } else {
                        if(token!=null){
                            Toast.makeText(context, "Already subscribed", Toast.LENGTH_SHORT).show()
                        }else
                        Toast.makeText(context, "Authorise to subscribe", Toast.LENGTH_SHORT).show()

                    }
                }
            }) {
                Icon(Icons.Default.Notifications, contentDescription = "Notification")
            }
        }

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            LazyColumn {
                items(filteredRaises) { raise ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                            .clickable { onRaiseClick(raise) },
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = raise.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Goal: $${raise.goal}",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Deadline: ${raise.deadlineDate}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RaiseSortDropDown(
    selectedSort: RaiseSortType,
    onSortSelected: (RaiseSortType) -> Unit,
    sortAscending: Boolean,
    onToggleOrder: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    val arrowIcon = if (sortAscending) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown

    Box(modifier = modifier.height(56.dp)) {
        OutlinedButton(
            onClick = { expanded = true },
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxHeight().width(160.dp)
        ) {
            Text(text = selectedSort.label)
            Spacer(modifier = Modifier.width(4.dp))
            IconButton(onClick = { onToggleOrder() }, modifier = Modifier.size(24.dp)) {
                Icon(imageVector = arrowIcon, contentDescription = "Toggle sort")
            }
        }

        DropdownMenu(
            expanded = expanded,
            shape = RoundedCornerShape(16.dp),
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(Color.White)
        ) {
            RaiseSortType.entries.forEach { type ->
                DropdownMenuItem(
                    text = { Text(type.label) },
                    onClick = {
                        onSortSelected(type)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun StatChartDialog(stats: List<InitiativeStat>, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        },
        title = { Text("Fundraising Trend") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(500.dp)
                    .padding(vertical = 8.dp)
            ) {
                // 1) Chart area
                ChartContent(
                    stats = stats,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                )

                Spacer(Modifier.height(8.dp))

                // 2) Header for the list
                Text(
                    "Donations by day",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(start = 8.dp, bottom = 4.dp)
                )

                // 3) Scrollable day→amount list
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                ) {
                    items(stats) { stat ->
                        // reuse your dd.MM formatting
                        val label = runCatching {
                            LocalDate
                                .parse(stat.date.substringBefore('T'), DateTimeFormatter.ISO_LOCAL_DATE)
                                .format(DateTimeFormatter.ofPattern("dd.MM"))
                        }.getOrElse { stat.date.takeLast(5).replace('-', '.') }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(label, style = MaterialTheme.typography.bodyMedium)
                            Text("${stat.totalAmount}", style = MaterialTheme.typography.bodyMedium)
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    )
}

@Composable
fun ChartContent(stats: List<InitiativeStat>, modifier: Modifier = Modifier) {
    if (stats.isEmpty()) {
        Text("No data to display.")
        return
    }


    val fmtIn  = DateTimeFormatter.ISO_LOCAL_DATE
    val fmtOut = DateTimeFormatter.ofPattern("dd.MM")
    val xLabels = stats.map { stat ->
        stat.date.substringBefore('T').let { raw ->
            runCatching {
                LocalDate.parse(raw, fmtIn).format(fmtOut)
            }.getOrElse {
                raw.takeLast(5).replace('-', '.')
            }
        }
    }

    val maxVal = stats.maxOf { it.totalAmount }.toDouble()
    val yMin = 0.0
    val yMax = maxVal * 1.1

    val modelProducer = remember { CartesianChartModelProducer() }
    LaunchedEffect(stats) {
        modelProducer.runTransaction {
            columnSeries {
                series(stats.map { it.totalAmount })
            }
        }
    }

    CartesianChartHost(
        chart = rememberCartesianChart(
            rememberColumnCartesianLayer(
                columnProvider = ColumnCartesianLayer.ColumnProvider.series(
                    rememberLineComponent(fill(Color.Black), 22.dp,  shape = CorneredShape.rounded(
                        topLeftPercent = 25,
                        topRightPercent = 25
                    ))
                ),
                columnCollectionSpacing = 16.dp,
                rangeProvider = CartesianLayerRangeProvider.fixed(yMin, yMax)
            ),
            startAxis = VerticalAxis.rememberStart(),
            bottomAxis = HorizontalAxis.rememberBottom(
                label = rememberTextComponent(textSize = 12.sp),
                valueFormatter = { _, value, _ ->
                    xLabels.getOrNull(value.toInt()) ?: value.toInt().toString()
                },
                labelRotationDegrees = 90f
            )
        ),
        modelProducer = modelProducer,
        modifier = modifier
    )
}

suspend fun fetchRaisesForInitiative(initiativeId: Int): List<Raise> {
    return try {
        val client = OkHttpClient()
        val request = Request.Builder()
            .url("http://10.0.2.2:5000/api/Fundraisings/byInitiative/$initiativeId")
            .addHeader("accept", "text/plain")
            .build()

        val response = withContext(Dispatchers.IO) {
            client.newCall(request).execute()
        }

        if (response.isSuccessful) {
            val body = response.body?.string() ?: return emptyList()
            val jsonArray = JSONArray(body)
            (0 until jsonArray.length()).map { i ->
                val obj = jsonArray.getJSONObject(i)
                Raise(
                    id = obj.getInt("id"),
                    name = obj.getString("title"),
                    goal = obj.getInt("goalAmount"),
                    deadlineDate = obj.getString("deadline").substringBefore("T"),
                    initiativeId = initiativeId
                )
            }
        } else emptyList()
    } catch (e: Exception) {
        Log.w("FetchRaises", "Unsuccessful response: $e")
        emptyList()
    }
}

suspend fun fetchInitiativeStats(id: Int): List<InitiativeStat> {
    return try {
        val client = OkHttpClient()
        val request = Request.Builder()
            .url("http://10.0.2.2:5000/api/Initiative/InitiativeStat?id=$id")
            .build()

        val response = withContext(Dispatchers.IO) {
            client.newCall(request).execute()
        }

        if (response.isSuccessful) {
            val body = response.body?.string() ?: return emptyList()
            val jsonArray = JSONArray(body)
            (0 until jsonArray.length()).map { i ->
                val obj = jsonArray.getJSONObject(i)
                InitiativeStat(
                    date = obj.getString("date"),
                    totalAmount = obj.getInt("totalAmount")
                )
            }
        } else emptyList()
    } catch (e: Exception) {
        Log.e("FetchStats", "Error: ${e.message}")
        emptyList()
    }
}


suspend fun subscribeToInitiative(initiativeId: Int, token: String?): Boolean {
    if (token.isNullOrEmpty()) return false

    val client = OkHttpClient()
    val jsonBody = JSONObject().put("initiativeId", initiativeId).toString()
    val mediaType = "application/json-patch+json".toMediaType()

    val request = Request.Builder()
        .url("http://10.0.2.2:5000/api/Subscribe")
        .addHeader("accept", "*/*")
        .addHeader("Authorization", "Bearer $token")
        .post(jsonBody.toRequestBody(mediaType))
        .build()

    return try {
        val response = withContext(Dispatchers.IO) {
            client.newCall(request).execute()
        }
        response.isSuccessful
    } catch (e: Exception) {
        false
    }
}