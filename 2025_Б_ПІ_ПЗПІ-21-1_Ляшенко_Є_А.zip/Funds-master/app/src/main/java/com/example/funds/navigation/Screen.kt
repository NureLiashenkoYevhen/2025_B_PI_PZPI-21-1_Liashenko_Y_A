package com.example.funds.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Profile : Screen("profile")
    object Subscriptions : Screen("subscriptions")
    object Initiative : Screen("initiative/{initiativeId}") {
        fun createRoute(id: Int) = "initiative/$id"
    }
    object Raise : Screen("raise/{raiseId}") {
        fun createRoute(id: Int) = "raise/$id"
    }
}
